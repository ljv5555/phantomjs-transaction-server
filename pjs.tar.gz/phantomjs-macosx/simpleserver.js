"use strict";
var port, server, service,
    system = require('system');

if (system.args.length !== 2) {
    system.args[1]='8484';
    console.log('no port number provided... defaulting to port '+port);
}
port=system.args[1];
else{
    console.log("Server port: "+serverPort);
}
    var sp = new URL(request.url).searchParams;
    var spk = sp.keys();
    var httpParams = new Array();
    while(true)
    {
      var n = spk.next();
      if(n && !(n.done))
      {
        var nvp=new Object();
        nvp['name']=n['value'];
        nvp['value']=sp.get(nvp['name']);
        httpParams.push();
      }
      else{break;}
    }
    server = require('webserver').create();
    console.log("Created server.");
    service = server.listen(port, function (request, response) {
        var ts = (new Date()).getTime();
        console.log('Request at ' + ts);
        console.log(JSON.stringify(request, null, 4));

        response.statusCode = 200;
        response.headers = {
            'Cache': 'no-cache',
            'Content-Type': 'text/plain'
        };
        response.write('request.parameters='+JSON.stringify(httpParams));
        response.close();
       
    });
    console.log("service listening");

    if (service) {
        console.log('Web server running on port ' + port);
    } else {
        console.log('Error: Could not create web server listening on port ' + port);
        phantom.exit();
    }
}

